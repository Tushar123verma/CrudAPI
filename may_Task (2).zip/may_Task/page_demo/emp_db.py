import sqlite3
def create_db():
    con=sqlite3.connect(database=r'emp.db')
    cur=con.cursor()
    cur.execute('CREATE TABLE IF NOT EXISTS employee(id INTEGER PRIMARY KEY AUTOINCREMENT,Ecode text,name text,dob text,dept text,salary text)')
    con.commit()
    #cur=con.cursor()
create_db()