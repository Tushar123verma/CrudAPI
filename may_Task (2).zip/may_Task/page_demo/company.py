from tkinter import*
#from PIL import Image,ImageTk
from tkinter import ttk,messagebox
from Dept import dept
from emp_table import Empinfo

class comp:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1580x780+0+0") 
        self.root.title("company page") 
        self.root.config(bg="white") 
        
        #self.icon_title=Image.open("logoErp.jpeg")
        #self.icon_title=self.icon_title.resize((70,70),Image.ANTIALIAS)
        title=Label(self.root,text="Company\t\t\t\t\tMy module",compound=LEFT,font=("times new roman",20,"bold"),bg="#4A4A70",fg="white",anchor="w",padx=250).place(x=0,y=-4,relwidth=1,height=80)
        
        #left menu
        left_menu=Frame(self.root,bd=1,relief=RIDGE,bg="white")
        left_menu.place(x=0,y=102,width=280,height=610)
        
        btn_dept=Button(left_menu,text="DEPT.",font=("times new roman",15,"bold"),command=self.dept,compound=LEFT,padx=6,anchor="w",bg="white",cursor="hand2",bd=2).pack(side=TOP,fill=X)
        btn_emp=Button(left_menu,text="Employee",font=("times new roman",15,"bold"),command=self.Empinfo,compound=LEFT,padx=6,anchor="w",bg="white",cursor="hand2",bd=2).pack(side=TOP,fill=X)
        
        
        
    def dept(self):
        self.new_wind=Toplevel(self.root) 
        self.new_obj=dept(self.new_wind)
        
    def Empinfo(self):
        self.new_wind=Toplevel(self.root)
        self.new_obj=Empinfo(self.new_wind)

root=Tk()
obj=comp(root)
root.mainloop()
        