from tkinter import*
from PIL import Image,ImageTk
from tkinter import ttk,messagebox
from add import Add
from emp_savepage import emp_save
import sqlite3
#from Dept import dept

class Empinfo:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1580x780+0+0")
        self.root.title("company page")
        self.root.config(bg="white")
        self.root.focus_force()
        
        self.var_id=StringVar()
        self.var_Ecode=StringVar()
        self.var_name=StringVar()
        self.var_dob=StringVar()
        self.var_dept=StringVar()
        self.var_salary=StringVar()
        
        #self.icon_title=Image.open("logoErp.jpeg")
        #self.icon_title=self.icon_title.resize((70,70),Image.ANTIALIAS)
        title=Label(self.root,text="Company\t\t\t\t\tMy module",compound=LEFT,font=("times new roman",20,"bold"),bg="#4A4A70",fg="white",anchor="w",padx=250).place(x=0,y=-4,relwidth=1,height=80)
        
        #left menu
        left_menu=Frame(self.root,bd=1,relief=RIDGE,bg="white")
        left_menu.place(x=0,y=102,width=280,height=610)
        
        btn_dept=Button(left_menu,text="DEPT.",font=("times new roman",15,"bold"),compound=LEFT,padx=6,anchor="w",bg="white",cursor="hand2",bd=2).pack(side=TOP,fill=X)
        btn_emp=Button(left_menu,text="Employee",font=("times new roman",15,"bold"),compound=LEFT,padx=6,anchor="w",bg="white",cursor="hand2",bd=2).pack(side=TOP,fill=X)
        
        
        #content_btn
        btn_create=Button(self.root,text="Create",command=self.emp_save,font=("goudy old style",15,"bold"),bg="Grey",fg="white").place(x=350,y=90,height=50,width=110)
        btn_delete=Button(self.root,text="Delete",command=self.delete,font=("goudy old style",15,"bold"),bg="Grey",fg="white").place(x=500,y=90,height=50,width=110)
        
        
        #Info_Table
        emp_frame=Frame(self.root,bd=3,relief=RIDGE)
        emp_frame.place(x=350,y=200,width=600,height=200)
        
        self.employee_infoTable=ttk.Treeview(emp_frame,columns=('id','ecode','name','dob','dept','salary'))
        
        self.employee_infoTable.heading('id',text='Id')
        self.employee_infoTable.heading('ecode',text='Ecode')
        self.employee_infoTable.heading('name',text='Name')
        self.employee_infoTable.heading('dob',text='DOB')
        self.employee_infoTable.heading('dept',text='Dept')
        self.employee_infoTable.heading('salary',text='Salary')
        
        
        self.employee_infoTable["show"]="headings"
        
        self.employee_infoTable.column('id',width=90)
        self.employee_infoTable.column('ecode',width=100)
        self.employee_infoTable.column('name',width=100)
        self.employee_infoTable.column('dob',width=90)
        self.employee_infoTable.column('dept',width=100)
        self.employee_infoTable.column('salary',width=100)
        self.employee_infoTable.bind("<ButtonRelease-1>",self.get_data)
        self.employee_infoTable.pack(fill=BOTH,expand=1)
        self.show()
        
        
    #show
    def show(self):
        con=sqlite3.Connection(database=r'emp.db')
        cur=con.cursor()
        try:
            cur.execute("select * from employee")
            rows=cur.fetchall()
            self.employee_infoTable.delete(*self.employee_infoTable.get_children())
            for row in rows:
                self.employee_infoTable.insert('',END,values=row)
        except Exception as e:
            messagebox.showerror('Error',f'error due to: {str(e)}',parent=self.root)
            
    def get_data(self,ev):
        f=self.employee_infoTable.focus()
        content=(self.employee_infoTable.item(f))
        row=content['values']
        #print(row)
        self.var_id.set(row[0])
        self.var_Ecode.set(row[1])
        self.var_name.set(row[2])
        self.var_dob.set(row[3])
        self.var_dept.set(row[4])
        self.var_salary.set(row[5])
             
                
    def delete(self):
        con=sqlite3.Connection(database=r'emp.db')
        cur=con.cursor()
        try:
            if self.var_id.get()=="":
                messagebox.showerror("Error",'ID must be required',parent=self.root)
            else:
                cur.execute('Select * from employee where id=?',(self.var_id.get(),))
                row=cur.fetchone()
                if row==None:
                    messagebox.showerror('Error',"Invalid ID",parent=self.root)
                else:
                    op=messagebox.askyesno('confirm','Do you want to delete?',parent=self.root)
                    if op==True:
                        cur.execute("delete from employee where id=?", (self.var_id.get(),))
                        con.commit()
                        messagebox.showinfo("Success","Employee info Deleted successfully",parent=self.root) 
        except Exception as e:
            messagebox.showerror('Error',f'error due to: {str(e)}',parent=self.root)
        
        
    def Add(self):
        self.new_wind=Toplevel(self.root)
        self.new_obj=Add(self.new_wind)
        
    def emp_save(self):
        self.new_wind=Toplevel(self.root)
        self.new_obj=emp_save(self.new_wind)
        
if __name__=='__main__':  
    root=Tk()
    obj=Empinfo(root)
    root.mainloop()