import sqlite3
def create_db():
    con=sqlite3.connect(database=r'dept1.db')
    cur=con.cursor()
    cur.execute('CREATE TABLE IF NOT EXISTS dept(id INTEGER PRIMARY KEY AUTOINCREMENT,code text,name text)')
    con.commit()
create_db()
