from tkinter import*
from PIL import Image,ImageTk
from tkinter import ttk,messagebox
import sqlite3

class Add:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1580x780+0+0")
        self.root.title("company page")
        self.root.config(bg="white")
        self.root.focus_force()
        
        self.var_code=StringVar()
        self.var_name=StringVar()
        
        
        #self.icon_title=Image.open("logoErp.jpeg")
        #self.icon_title=self.icon_title.resize((70,70),Image.ANTIALIAS)
        title=Label(self.root,text="Company\t\t\t\t\tMy module",compound=LEFT,font=("times new roman",20,"bold"),bg="#4A4A70",fg="white",anchor="w",padx=250).place(x=0,y=-4,relwidth=1,height=80)
        
        #left_menu
        left_menu=Frame(self.root,bd=1,relief=RIDGE,bg="white")
        left_menu.place(x=0,y=102,width=280,height=610)
        
        btn_dept=Button(left_menu,text="DEPT.",font=("times new roman",15,"bold"),compound=LEFT,padx=6,anchor="w",bg="white",cursor="hand2",bd=2).pack(side=TOP,fill=X)
        btn_emp=Button(left_menu,text="Employee",font=("times new roman",15,"bold"),compound=LEFT,padx=6,anchor="w",bg="white",cursor="hand2",bd=2).pack(side=TOP,fill=X)
        
        
        #content_btn
        btn_Save=Button(self.root,text="Save",font=("goudy old style",15,"bold"),command=self.save,bg="Grey",fg="white").place(x=350,y=90,height=50,width=110)
        
        
        #Text
        code_lbl=Label(self.root,text="Code",font=("times new roman",15),bg="white").place(x=350,y=250)
        code_txt=Entry(self.root,textvariable=self.var_code,font=("times new roman",15),bg="lightyellow").place(x=450,y=250)
        name_lbl=Label(self.root,text="Name",font=("times new roman",15),bg="white").place(x=350,y=300)
        name_txt=Entry(self.root,textvariable=self.var_name,font=("times new roman",15),bg="lightyellow").place(x=450,y=300)
        
        
    #_______saveButton__________
    def save(self):
        con=sqlite3.Connection(database=r'dept1.db')
        cur=con.cursor()
        try:
            if self.var_code.get()=="":
                messagebox.showerror("Error",'dept code must be required',parent=self.root)
            else:
                cur.execute('Select * from dept where code=?',(self.var_code.get(),))
                row=cur.fetchone()
            if row!=None:
                messagebox.showerror('Error',"This code already registered",parent=self.root)
            else:
                cur.execute("Insert into dept(code,name) values(?,?)",(
                    self.var_code.get(),
                    self.var_name.get(),
                        
                        
                ))
                con.commit()
                messagebox.showinfo("Success","deptinfo added successfully",parent=self.root) 
                #self.show()   
        except Exception as e:
            messagebox.showerror('Error',f'error due to: {str(e)}',parent=self.root)
            
    '''def Empinfo(self):
        self.new_wind=Toplevel(self.root)
        self.new_obj=Empinfo(self.new_wind)
    '''
        
        
if __name__=='__main__':  
    root=Tk()
    obj=Add(root)
    root.mainloop()